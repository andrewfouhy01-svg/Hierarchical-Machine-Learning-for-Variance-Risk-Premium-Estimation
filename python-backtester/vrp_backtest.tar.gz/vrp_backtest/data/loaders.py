"""File-specific loaders handling RDS, CSV, and XLSX with various date formats."""

import logging
import pandas as pd
import pyreadr
from pathlib import Path

logger = logging.getLogger(__name__)


def load_rds(path: str) -> pd.DataFrame:
    """Load an RDS file and return a DataFrame with date column as datetime."""
    logger.info(f"Loading RDS: {path}")
    result = pyreadr.read_r(path)
    df = list(result.values())[0]
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"])
    return df


def load_rv_forecasts(path: str) -> pd.DataFrame:
    """Load RV forward regression CSV (YYYY-MM-DD dates)."""
    logger.info(f"Loading RV forecasts: {path}")
    df = pd.read_csv(path, parse_dates=["date"])
    return df


def load_vix_regression(path: str) -> pd.DataFrame:
    """Load VIX regression XLSX (YYYY-MM-DD dates)."""
    logger.info(f"Loading VIX regression: {path}")
    df = pd.read_excel(path, engine="openpyxl")
    df["date"] = pd.to_datetime(df["date"])
    return df


def load_rv_classification(path: str) -> pd.DataFrame:
    """Load RV classification XLSX (YYYY-MM-DD dates)."""
    logger.info(f"Loading RV classification: {path}")
    df = pd.read_excel(path, engine="openpyxl")
    df["date"] = pd.to_datetime(df["date"])
    return df


def load_vix_classification(path: str) -> pd.DataFrame:
    """Load VIX classification XLSX (DD/MM/YYYY dates)."""
    logger.info(f"Loading VIX classification: {path}")
    df = pd.read_excel(path, engine="openpyxl")
    df["date"] = pd.to_datetime(df["date"], dayfirst=True)
    return df


def load_option_chain(path: str) -> pd.DataFrame:
    """Load the SPX option chain XLSX (M/DD/YYYY dates). Cache as parquet."""
    parquet_path = Path(path).with_suffix(".parquet")
    if parquet_path.exists():
        logger.info(f"Loading cached option chain from parquet: {parquet_path}")
        df = pd.read_parquet(parquet_path)
        return df

    logger.info(f"Loading option chain XLSX (this may take a while): {path}")
    df = pd.read_excel(path, engine="openpyxl")

    # Parse dates - M/DD/YYYY format
    for col in ["Date", "Expiration"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], format="mixed", dayfirst=False)

    # Cache as parquet for subsequent runs
    try:
        df.to_parquet(parquet_path)
        logger.info(f"Cached option chain to: {parquet_path}")
    except Exception as e:
        logger.warning(f"Could not cache to parquet: {e}")

    return df
