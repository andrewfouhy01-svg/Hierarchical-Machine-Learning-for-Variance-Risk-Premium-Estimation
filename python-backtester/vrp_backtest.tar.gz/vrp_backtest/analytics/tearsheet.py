"""Generate interactive HTML tearsheet with Plotly."""

import logging
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from analytics.metrics import PerformanceMetrics
from strategy.portfolio import Portfolio

logger = logging.getLogger(__name__)


def generate_tearsheet(
    portfolio: Portfolio,
    metrics: PerformanceMetrics,
    output_path: str = "tearsheet.html",
) -> str:
    """Generate a self-contained HTML tearsheet."""

    # Build DataFrames
    snap_df = pd.DataFrame([
        {"date": s.date, "nav": s.nav} for s in portfolio.snapshots
    ])
    snap_df["date"] = pd.to_datetime(snap_df["date"])
    snap_df = snap_df.drop_duplicates(subset="date", keep="last").sort_values("date")

    trade_df = pd.DataFrame([
        {
            "entry_date": c.trade.entry_date,
            "expiry": c.trade.expiry,
            "short_strike": c.trade.short_put_strike,
            "long_strike": c.trade.long_put_strike,
            "contracts": c.trade.contracts,
            "credit": c.trade.total_credit,
            "pnl": c.pnl,
            "pnl_pct": c.pnl_pct_nav,
            "spot_entry": c.trade.entry_spot,
            "spot_expiry": c.spot_at_expiry,
            "vix_entry": c.trade.entry_vix,
            "dte": c.trade.dte,
            "size_scalar": c.trade.size_scalar,
            "exit_reason": c.exit_reason,
        }
        for c in portfolio.closed_positions
    ])

    # ---- Figures ----
    figs = []

    # 1. Equity curve with drawdown
    fig1 = make_subplots(
        rows=2, cols=1, shared_xaxes=True,
        row_heights=[0.7, 0.3],
        subplot_titles=["Equity Curve", "Drawdown"],
        vertical_spacing=0.08,
    )
    fig1.add_trace(
        go.Scatter(x=snap_df["date"], y=snap_df["nav"], name="NAV", line=dict(color="#2563eb")),
        row=1, col=1,
    )
    # Drawdown
    cummax = snap_df["nav"].cummax()
    dd = (snap_df["nav"] - cummax) / cummax
    fig1.add_trace(
        go.Scatter(x=snap_df["date"], y=dd, fill="tozeroy", name="Drawdown",
                   line=dict(color="#dc2626"), fillcolor="rgba(220,38,38,0.3)"),
        row=2, col=1,
    )
    fig1.update_layout(height=500, title_text="Portfolio Performance", showlegend=True)
    fig1.update_yaxes(title_text="NAV ($)", row=1, col=1)
    fig1.update_yaxes(title_text="Drawdown", tickformat=".1%", row=2, col=1)
    figs.append(fig1)

    # 2. Trade P&L scatter
    if not trade_df.empty:
        trade_df["entry_date"] = pd.to_datetime(trade_df["entry_date"])
        colors = ["#16a34a" if p > 0 else "#dc2626" for p in trade_df["pnl"]]
        fig2 = go.Figure()
        fig2.add_trace(go.Bar(
            x=trade_df["entry_date"], y=trade_df["pnl"],
            marker_color=colors, name="Trade P&L",
        ))
        fig2.update_layout(
            height=350, title_text="Individual Trade P&L",
            xaxis_title="Entry Date", yaxis_title="P&L ($)",
        )
        figs.append(fig2)

    # 3. Monthly returns heatmap
    if not trade_df.empty:
        trade_df["month"] = trade_df["entry_date"].dt.month
        trade_df["year"] = trade_df["entry_date"].dt.year
        monthly_pnl = trade_df.groupby(["year", "month"])["pnl"].sum().reset_index()
        pivot = monthly_pnl.pivot(index="year", columns="month", values="pnl").fillna(0)

        month_labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        fig3 = go.Figure(data=go.Heatmap(
            z=pivot.values,
            x=[month_labels[m - 1] for m in pivot.columns],
            y=pivot.index.astype(str),
            colorscale="RdYlGn",
            zmid=0,
            text=[[f"${v:,.0f}" for v in row] for row in pivot.values],
            texttemplate="%{text}",
            textfont={"size": 10},
        ))
        fig3.update_layout(height=400, title_text="Monthly P&L Heatmap")
        figs.append(fig3)

    # 4. Return distribution
    if len(snap_df) > 2:
        rets = snap_df["nav"].pct_change().dropna()
        fig4 = go.Figure()
        fig4.add_trace(go.Histogram(
            x=rets, nbinsx=40, name="Returns",
            marker_color="#2563eb", opacity=0.7,
        ))
        fig4.update_layout(
            height=350, title_text="Return Distribution",
            xaxis_title="Return", yaxis_title="Frequency",
        )
        figs.append(fig4)

    # 5. Cumulative P&L by trade
    if not trade_df.empty:
        cum_pnl = trade_df["pnl"].cumsum()
        fig5 = go.Figure()
        fig5.add_trace(go.Scatter(
            x=trade_df["entry_date"], y=cum_pnl,
            mode="lines+markers", name="Cumulative P&L",
            line=dict(color="#7c3aed"),
        ))
        fig5.update_layout(
            height=350, title_text="Cumulative Trade P&L",
            xaxis_title="Entry Date", yaxis_title="Cumulative P&L ($)",
        )
        figs.append(fig5)

    # ---- Build HTML ----
    metrics_html = _metrics_table(metrics)
    trades_html = _trades_table(trade_df) if not trade_df.empty else "<p>No trades.</p>"
    plots_html = "\n".join(
        f'<div class="chart">{fig.to_html(full_html=False, include_plotlyjs=False)}</div>'
        for fig in figs
    )

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>VRP Strategy Tearsheet</title>
<script src="https://cdn.plot.ly/plotly-2.27.0.min.js"></script>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
         margin: 20px; background: #f8fafc; color: #1e293b; }}
  h1 {{ color: #0f172a; border-bottom: 2px solid #2563eb; padding-bottom: 10px; }}
  h2 {{ color: #334155; margin-top: 30px; }}
  .metrics-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
                   gap: 12px; margin: 20px 0; }}
  .metric-card {{ background: white; border-radius: 8px; padding: 16px;
                  box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
  .metric-card .label {{ color: #64748b; font-size: 0.85em; }}
  .metric-card .value {{ font-size: 1.3em; font-weight: 600; color: #0f172a; }}
  .chart {{ margin: 20px 0; background: white; border-radius: 8px;
            padding: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
  table {{ border-collapse: collapse; width: 100%; margin: 10px 0; font-size: 0.85em; }}
  th, td {{ border: 1px solid #e2e8f0; padding: 8px 12px; text-align: right; }}
  th {{ background: #f1f5f9; font-weight: 600; }}
  tr:nth-child(even) {{ background: #f8fafc; }}
  .pos {{ color: #16a34a; }} .neg {{ color: #dc2626; }}
</style>
</head>
<body>
<h1>VRP Signal-Gated SPX Options Strategy: Tearsheet</h1>
<p>Hold-to-expiry bull put spread strategy, gated by XGBoost VRP and regime signals.</p>

<h2>Performance Summary</h2>
{metrics_html}

<h2>Charts</h2>
{plots_html}

<h2>Trade Log (first 200)</h2>
{trades_html}

<p style="color:#94a3b8; font-size:0.8em; margin-top:40px;">
  Generated by VRP Backtest System. All P&L figures in USD.
</p>
</body>
</html>"""

    Path(output_path).write_text(html)
    logger.info(f"Tearsheet saved to {output_path}")
    return output_path


def _metrics_table(m: PerformanceMetrics) -> str:
    cards = [
        ("Total Return", f"{m.total_return:.2%}"),
        ("CAGR", f"{m.cagr:.2%}"),
        ("Annualised Vol", f"{m.annualised_vol:.2%}"),
        ("Sharpe Ratio", f"{m.sharpe:.2f}"),
        ("Sortino Ratio", f"{m.sortino:.2f}"),
        ("Calmar Ratio", f"{m.calmar:.2f}"),
        ("Omega Ratio", f"{m.omega:.2f}"),
        ("Max Drawdown", f"{m.max_drawdown:.2%}"),
        ("Max DD Duration", f"{m.max_drawdown_duration_days} days"),
        ("VaR (95%)", f"{m.var_95:.2%}"),
        ("CVaR (95%)", f"{m.cvar_95:.2%}"),
        ("VaR (99%)", f"{m.var_99:.2%}"),
        ("CVaR (99%)", f"{m.cvar_99:.2%}"),
        ("Total Trades", f"{m.total_trades}"),
        ("Hit Rate", f"{m.hit_rate:.1%}"),
        ("Avg Win", f"${m.avg_win:,.0f}"),
        ("Avg Loss", f"${m.avg_loss:,.0f}"),
        ("Profit Factor", f"{m.profit_factor:.2f}"),
        ("Premium Capture", f"{m.premium_capture_ratio:.2%}"),
        ("Avg Monthly Return", f"{m.avg_monthly_return:.2%}"),
        ("Best Month", f"{m.best_month:.2%}"),
        ("Worst Month", f"{m.worst_month:.2%}"),
        ("% Positive Months", f"{m.pct_positive_months:.1%}"),
    ]
    html = '<div class="metrics-grid">'
    for label, value in cards:
        html += f'<div class="metric-card"><div class="label">{label}</div><div class="value">{value}</div></div>'
    html += "</div>"
    return html


def _trades_table(df: pd.DataFrame) -> str:
    cols = ["entry_date", "expiry", "short_strike", "long_strike", "contracts",
            "credit", "pnl", "pnl_pct", "spot_entry", "spot_expiry", "vix_entry",
            "dte", "size_scalar"]
    sub = df[cols].head(200)
    html = "<table><thead><tr>"
    for c in cols:
        html += f"<th>{c}</th>"
    html += "</tr></thead><tbody>"
    for _, row in sub.iterrows():
        html += "<tr>"
        for c in cols:
            val = row[c]
            if c == "pnl":
                cls = "pos" if val > 0 else "neg"
                html += f'<td class="{cls}">${val:,.0f}</td>'
            elif c == "pnl_pct":
                cls = "pos" if val > 0 else "neg"
                html += f'<td class="{cls}">{val:.2%}</td>'
            elif c == "credit":
                html += f"<td>${val:,.0f}</td>"
            elif c in ("entry_date", "expiry"):
                html += f"<td>{val}</td>"
            elif isinstance(val, float):
                html += f"<td>{val:.2f}</td>"
            else:
                html += f"<td>{val}</td>"
        html += "</tr>"
    html += "</tbody></table>"
    return html
