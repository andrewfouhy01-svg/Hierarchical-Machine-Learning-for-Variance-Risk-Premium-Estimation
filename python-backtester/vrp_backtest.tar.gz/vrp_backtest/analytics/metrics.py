"""Performance metrics: Sharpe, Sortino, Calmar, max drawdown, VaR, etc."""

import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Optional


@dataclass
class PerformanceMetrics:
    # Returns
    total_return: float
    cagr: float
    annualised_vol: float
    # Risk-adjusted
    sharpe: float
    sortino: float
    calmar: float
    omega: float
    # Drawdown
    max_drawdown: float
    max_drawdown_duration_days: int
    # Tail risk
    var_95: float
    cvar_95: float
    var_99: float
    cvar_99: float
    # Trade stats
    total_trades: int
    winning_trades: int
    losing_trades: int
    hit_rate: float
    avg_win: float
    avg_loss: float
    profit_factor: float
    premium_capture_ratio: float
    # Summary
    avg_monthly_return: float
    best_month: float
    worst_month: float
    pct_positive_months: float


def compute_metrics(
    portfolio,
    risk_free_rate: float = 0.04,
) -> PerformanceMetrics:
    """Compute full performance metrics from a completed portfolio."""

    snapshots = portfolio.snapshots
    closed = portfolio.closed_positions

    if len(snapshots) < 2:
        return _empty_metrics()

    # Build NAV series
    nav_series = pd.DataFrame([
        {"date": s.date, "nav": s.nav} for s in snapshots
    ])
    nav_series["date"] = pd.to_datetime(nav_series["date"])
    nav_series = nav_series.drop_duplicates(subset="date", keep="last")
    nav_series = nav_series.sort_values("date").reset_index(drop=True)

    # Daily returns (between snapshot dates)
    nav_series["return"] = nav_series["nav"].pct_change()
    returns = nav_series["return"].dropna()

    if len(returns) == 0:
        return _empty_metrics()

    initial_nav = portfolio.initial_capital
    final_nav = nav_series["nav"].iloc[-1]
    total_return = final_nav / initial_nav - 1

    # Time span in years
    days = (nav_series["date"].iloc[-1] - nav_series["date"].iloc[0]).days
    years = days / 365.25 if days > 0 else 1.0

    cagr = (final_nav / initial_nav) ** (1 / years) - 1 if years > 0 else 0.0

    # Annualised vol (scale by sqrt of avg periods per year)
    # Since snapshots are monthly-ish, estimate periods per year
    periods_per_year = len(returns) / years if years > 0 else 12
    ann_vol = returns.std() * np.sqrt(periods_per_year) if len(returns) > 1 else 0.0

    # Sharpe
    rf_per_period = risk_free_rate / periods_per_year if periods_per_year > 0 else 0.0
    excess = returns - rf_per_period
    sharpe = (excess.mean() / excess.std() * np.sqrt(periods_per_year)) if excess.std() > 0 else 0.0

    # Sortino
    downside = returns[returns < rf_per_period] - rf_per_period
    downside_std = np.sqrt((downside ** 2).mean()) if len(downside) > 0 else 0.0
    sortino = ((returns.mean() - rf_per_period) / downside_std * np.sqrt(periods_per_year)
               if downside_std > 0 else 0.0)

    # Max drawdown
    cummax = nav_series["nav"].cummax()
    drawdown = (nav_series["nav"] - cummax) / cummax
    max_dd = drawdown.min()

    # Drawdown duration
    dd_duration = _max_drawdown_duration(nav_series["nav"].values, nav_series["date"].values)

    # Calmar
    calmar = cagr / abs(max_dd) if abs(max_dd) > 0 else 0.0

    # VaR / CVaR
    var_95 = returns.quantile(0.05)
    cvar_95 = returns[returns <= var_95].mean() if len(returns[returns <= var_95]) > 0 else var_95
    var_99 = returns.quantile(0.01)
    cvar_99 = returns[returns <= var_99].mean() if len(returns[returns <= var_99]) > 0 else var_99

    # Omega ratio
    threshold = rf_per_period
    gains = returns[returns > threshold] - threshold
    losses = threshold - returns[returns <= threshold]
    omega = gains.sum() / losses.sum() if losses.sum() > 0 else float("inf")

    # Trade statistics
    pnls = [c.pnl for c in closed]
    total_trades = len(pnls)
    wins = [p for p in pnls if p > 0]
    losses_list = [p for p in pnls if p <= 0]
    hit_rate = len(wins) / total_trades if total_trades > 0 else 0.0
    avg_win = np.mean(wins) if wins else 0.0
    avg_loss = np.mean(losses_list) if losses_list else 0.0
    gross_profit = sum(wins)
    gross_loss = abs(sum(losses_list))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float("inf")

    # Premium capture ratio: total P&L / total credit received
    total_credit = sum(c.trade.total_credit for c in closed)
    total_pnl = sum(pnls)
    premium_capture = (total_pnl + total_credit) / total_credit if total_credit > 0 else 0.0

    # Monthly returns
    nav_series["month"] = nav_series["date"].dt.to_period("M")
    monthly = nav_series.groupby("month")["nav"].last().pct_change().dropna()
    avg_monthly = monthly.mean() if len(monthly) > 0 else 0.0
    best_month = monthly.max() if len(monthly) > 0 else 0.0
    worst_month = monthly.min() if len(monthly) > 0 else 0.0
    pct_pos_months = (monthly > 0).mean() if len(monthly) > 0 else 0.0

    return PerformanceMetrics(
        total_return=total_return,
        cagr=cagr,
        annualised_vol=ann_vol,
        sharpe=sharpe,
        sortino=sortino,
        calmar=calmar,
        omega=omega,
        max_drawdown=max_dd,
        max_drawdown_duration_days=dd_duration,
        var_95=var_95,
        cvar_95=cvar_95,
        var_99=var_99,
        cvar_99=cvar_99,
        total_trades=total_trades,
        winning_trades=len(wins),
        losing_trades=len(losses_list),
        hit_rate=hit_rate,
        avg_win=avg_win,
        avg_loss=avg_loss,
        profit_factor=profit_factor,
        premium_capture_ratio=premium_capture,
        avg_monthly_return=avg_monthly,
        best_month=best_month,
        worst_month=worst_month,
        pct_positive_months=pct_pos_months,
    )


def _max_drawdown_duration(navs, dates) -> int:
    """Compute max drawdown duration in days."""
    peak = navs[0]
    max_dur = 0
    peak_date = dates[0]
    for i in range(1, len(navs)):
        if navs[i] >= peak:
            peak = navs[i]
            peak_date = dates[i]
        else:
            dur = (pd.Timestamp(dates[i]) - pd.Timestamp(peak_date)).days
            max_dur = max(max_dur, dur)
    return max_dur


def _empty_metrics() -> PerformanceMetrics:
    return PerformanceMetrics(
        total_return=0, cagr=0, annualised_vol=0,
        sharpe=0, sortino=0, calmar=0, omega=0,
        max_drawdown=0, max_drawdown_duration_days=0,
        var_95=0, cvar_95=0, var_99=0, cvar_99=0,
        total_trades=0, winning_trades=0, losing_trades=0,
        hit_rate=0, avg_win=0, avg_loss=0, profit_factor=0,
        premium_capture_ratio=0,
        avg_monthly_return=0, best_month=0, worst_month=0,
        pct_positive_months=0,
    )
