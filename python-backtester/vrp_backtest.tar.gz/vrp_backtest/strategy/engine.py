"""Main backtest engine: iterates over option chain dates, evaluates signals, enters trades."""

import logging
from datetime import date

import pandas as pd

from config.models import AppConfig
from data.manager import DataManager
from signals.composite import CompositeSignal
from strategy.portfolio import Portfolio
from strategy.trade_builder import build_put_spread

logger = logging.getLogger(__name__)


class BacktestEngine:
    """
    Simplified backtest engine for hold-to-expiry strategy.

    Workflow per option chain date:
      1. Settle any expired positions
      2. Evaluate composite signal
      3. If trade permitted and no existing position for this cycle, enter
      4. Record snapshot
    """

    def __init__(self, config: AppConfig, data_manager: DataManager):
        self.config = config
        self.dm = data_manager
        self.signal = CompositeSignal(config.signals, data_manager)
        self.portfolio = Portfolio(config.backtest.initial_capital)

    def run(self) -> Portfolio:
        """Execute the full backtest."""
        start = self.config.backtest.start_date
        end = self.config.backtest.end_date

        logger.info(f"Starting backtest: {start} to {end}")
        logger.info(f"Initial capital: ${self.config.backtest.initial_capital:,.0f}")

        # Precompute signals
        self.signal.precompute(start, end)

        # Get all option chain observation dates
        all_chain_dates = self.dm.get_option_chain_dates()
        chain_dates = [d for d in all_chain_dates if start <= d <= end]
        logger.info(f"Option chain dates in range: {len(chain_dates)}")

        if not chain_dates:
            logger.error("No option chain dates found in backtest range!")
            return self.portfolio

        trades_entered = 0
        trades_skipped_signal = 0
        trades_skipped_no_chain = 0
        trades_skipped_existing = 0
        trades_skipped_circuit = 0
        trades_skipped_build_fail = 0

        for chain_date in chain_dates:
            logger.debug(f"Processing chain date: {chain_date}")

            # 1. Settle expired positions
            settled = self.portfolio.settle_expired(chain_date)
            for closed in settled:
                self.portfolio.update_monthly_pnl(
                    closed.pnl,
                    chain_date,
                    self.config.strategy.circuit_breaker_monthly_pct,
                    self.config.strategy.circuit_breaker_cooloff_days,
                )

            # 2. Check circuit breaker
            if self.portfolio.check_circuit_breaker(
                chain_date,
                self.config.strategy.circuit_breaker_monthly_pct,
                self.config.strategy.circuit_breaker_cooloff_days,
            ):
                trades_skipped_circuit += 1
                self.portfolio.record_snapshot(chain_date)
                continue

            # 3. Get option chain
            dte_range = (
                self.config.strategy.min_dte_entry,
                self.config.strategy.max_dte_entry,
            )
            chain = self.dm.get_option_chain(chain_date, dte_range)
            if chain.empty:
                trades_skipped_no_chain += 1
                self.portfolio.record_snapshot(chain_date)
                continue

            # Check for existing position in this expiry cycle
            expiry_dates = chain["Expiration"].unique()
            if len(expiry_dates) == 0:
                trades_skipped_no_chain += 1
                self.portfolio.record_snapshot(chain_date)
                continue

            expiry = pd.Timestamp(expiry_dates[0]).date()
            if self.portfolio.has_position_for_expiry(expiry):
                trades_skipped_existing += 1
                self.portfolio.record_snapshot(chain_date)
                continue

            # 4. Evaluate composite signal
            decision = self.signal.evaluate(chain_date)

            if decision.action != "ENTER":
                trades_skipped_signal += 1
                self.portfolio.trade_log.append({
                    "action": "SKIP",
                    "date": chain_date,
                    "reason_codes": decision.reason_codes,
                    "vrp_regime": decision.signals.get("vrp").regime if decision.signals.get("vrp") else None,
                    "regime": decision.signals.get("regime").regime if decision.signals.get("regime") else None,
                })
                self.portfolio.record_snapshot(chain_date)
                continue

            # 5. Build and enter trade
            entry_spot = self.dm.get_spot(chain_date)
            entry_vix = self.dm.get_vix(chain_date)

            if entry_spot is None:
                entry_spot = float(chain["PriceDate"].iloc[0]) if "PriceDate" in chain.columns else 0.0
            if entry_vix is None:
                entry_vix = 0.0

            # Check if call overlay eligible
            call_overlay = "CALL_OVERLAY_ELIGIBLE" in decision.reason_codes

            trade = build_put_spread(
                chain=chain,
                strategy_config=self.config.strategy,
                execution_config=self.config.execution,
                nav=self.portfolio.nav,
                size_scalar=decision.size_scalar,
                entry_date=chain_date,
                entry_spot=entry_spot,
                entry_vix=entry_vix,
                call_overlay=call_overlay,
            )

            if trade is None:
                trades_skipped_build_fail += 1
                self.portfolio.record_snapshot(chain_date)
                continue

            self.portfolio.enter_trade(trade)
            trades_entered += 1
            self.portfolio.record_snapshot(chain_date)

        # Final settlement of any remaining positions
        if self.portfolio.open_positions:
            logger.info(f"Settling {len(self.portfolio.open_positions)} remaining positions at end")
            # Use end date for final settlement
            final_settled = self.portfolio.settle_expired(end)
            # For positions that still haven't expired, force-settle at last known spot
            for trade in list(self.portfolio.open_positions):
                spot = self.dm.get_spot(end)
                if spot is None:
                    spot = trade.entry_spot
                trade.spot_at_expiry = spot
                # Manually settle
                from strategy.portfolio import ClosedPosition
                pnl = self.portfolio._compute_expiry_pnl(trade, spot)
                self.portfolio.cash += pnl
                closed = ClosedPosition(
                    trade=trade,
                    exit_date=end,
                    spot_at_expiry=spot,
                    pnl=pnl,
                    pnl_pct_nav=pnl / self.portfolio.nav if self.portfolio.nav > 0 else 0.0,
                    exit_reason="BACKTEST_END",
                )
                self.portfolio.closed_positions.append(closed)
            self.portfolio.open_positions = []

        self.portfolio.record_snapshot(end)

        # Summary
        logger.info("=" * 60)
        logger.info("BACKTEST COMPLETE")
        logger.info(f"Trades entered:           {trades_entered}")
        logger.info(f"Skipped (signal):         {trades_skipped_signal}")
        logger.info(f"Skipped (no chain):       {trades_skipped_no_chain}")
        logger.info(f"Skipped (existing pos):   {trades_skipped_existing}")
        logger.info(f"Skipped (circuit breaker): {trades_skipped_circuit}")
        logger.info(f"Skipped (build fail):     {trades_skipped_build_fail}")
        logger.info(f"Final NAV:                ${self.portfolio.nav:,.0f}")
        logger.info(f"Total return:             {(self.portfolio.nav / self.config.backtest.initial_capital - 1):.2%}")
        logger.info("=" * 60)

        return self.portfolio
