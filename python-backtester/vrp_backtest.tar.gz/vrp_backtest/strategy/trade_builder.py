"""Trade builder: delta-targeted strike selection and spread construction."""

import logging
from dataclasses import dataclass
from datetime import date
from typing import Optional

import numpy as np
import pandas as pd

from config.models import StrategyConfig, ExecutionConfig

logger = logging.getLogger(__name__)


@dataclass
class SpreadTrade:
    """Represents a single put spread (or iron condor) trade at entry."""
    entry_date: date
    expiry: date
    # Put spread
    short_put_strike: float
    long_put_strike: float
    short_put_delta: float
    long_put_delta: float
    short_put_mid: float
    long_put_mid: float
    # Credit and risk
    entry_credit_per_spread: float  # net credit received per spread
    spread_width: float             # short_strike - long_strike (always positive for bull put)
    max_loss_per_spread: float      # spread_width * 100 - credit
    # Sizing
    contracts: int
    total_credit: float
    total_max_loss: float
    # Context
    entry_spot: float
    entry_vix: float
    dte: int
    size_scalar: float
    # Optional call overlay
    short_call_strike: Optional[float] = None
    short_call_delta: Optional[float] = None
    short_call_mid: Optional[float] = None
    call_credit_per_spread: Optional[float] = None
    # Expiry data for P&L
    spot_at_expiry: Optional[float] = None


def select_strike_by_delta(
    chain: pd.DataFrame,
    target_delta: float,
    option_type: str = "P",
) -> Optional[pd.Series]:
    """
    Select the option row closest to the target absolute delta.

    For puts, delta is negative; we match on |delta|.
    For calls, delta is positive.
    """
    sub = chain[chain["CallPut"] == option_type].copy()
    if sub.empty:
        return None

    if option_type == "P":
        sub["abs_delta"] = sub["Delta"].abs()
    else:
        sub["abs_delta"] = sub["Delta"].abs()

    # Filter out options with zero bid (illiquid)
    sub = sub[sub["BestBid"] > 0]
    if sub.empty:
        return None

    # Find closest to target delta
    sub["delta_diff"] = (sub["abs_delta"] - target_delta).abs()
    best_idx = sub["delta_diff"].idxmin()
    return sub.loc[best_idx]


def build_put_spread(
    chain: pd.DataFrame,
    strategy_config: StrategyConfig,
    execution_config: ExecutionConfig,
    nav: float,
    size_scalar: float,
    entry_date: date,
    entry_spot: float,
    entry_vix: float,
    call_overlay: bool = False,
) -> Optional[SpreadTrade]:
    """
    Build a 16-delta / 5-delta bull put spread from the option chain.

    Returns None if suitable strikes cannot be found.
    """
    # Select puts only
    puts = chain[chain["CallPut"] == "P"].copy()
    if puts.empty:
        logger.warning(f"No put options available for {entry_date}")
        return None

    # Get expiry from the chain
    expiry_dates = puts["Expiration"].unique()
    if len(expiry_dates) == 0:
        return None
    expiry = pd.Timestamp(expiry_dates[0]).date()
    dte = int(puts["Days"].iloc[0])

    # Short put: nearest to 16-delta
    short_put = select_strike_by_delta(puts, strategy_config.short_put_delta, "P")
    if short_put is None:
        logger.warning(f"Could not find short put strike for {entry_date}")
        return None

    # Long put: nearest to 5-delta (must be lower strike than short)
    long_put = select_strike_by_delta(puts, strategy_config.long_put_delta, "P")
    if long_put is None:
        logger.warning(f"Could not find long put strike for {entry_date}")
        return None

    # Ensure long strike < short strike (bull put spread)
    if long_put["Strike"] >= short_put["Strike"]:
        logger.warning(
            f"Long put strike ({long_put['Strike']}) >= short put strike ({short_put['Strike']}). "
            f"Skipping {entry_date}."
        )
        return None

    # Compute mid prices
    short_mid = float(short_put["MidPrice"]) if "MidPrice" in short_put.index else (
        (float(short_put["BestBid"]) + float(short_put["BestOffer"])) / 2
    )
    long_mid = float(long_put["MidPrice"]) if "MidPrice" in long_put.index else (
        (float(long_put["BestBid"]) + float(long_put["BestOffer"])) / 2
    )

    # Apply slippage: for a credit spread, we sell at worse than mid
    # Sell short put: receive less (mid minus fraction of half-spread)
    short_half_spread = (float(short_put["BestOffer"]) - float(short_put["BestBid"])) / 2
    sell_price = short_mid - execution_config.spread_fraction * short_half_spread

    # Buy long put: pay more (mid plus fraction of half-spread)
    long_half_spread = (float(long_put["BestOffer"]) - float(long_put["BestBid"])) / 2
    buy_price = long_mid + execution_config.spread_fraction * long_half_spread

    credit_per_spread = sell_price - buy_price
    if credit_per_spread <= 0:
        logger.warning(f"Negative credit ({credit_per_spread:.2f}) for {entry_date}. Skipping.")
        return None

    spread_width = float(short_put["Strike"]) - float(long_put["Strike"])
    max_loss_per_spread = spread_width * 100 - credit_per_spread * 100
    risk_per_spread = spread_width * 100  # max loss in dollar terms

    # Position sizing
    risk_budget = nav * strategy_config.max_risk_pct_nav * size_scalar
    contracts = int(np.floor(risk_budget / risk_per_spread)) if risk_per_spread > 0 else 0

    if contracts <= 0:
        logger.debug(f"Zero contracts for {entry_date} (risk_budget={risk_budget:.0f})")
        return None

    # Check margin utilisation
    total_margin = contracts * risk_per_spread
    if total_margin > nav * strategy_config.max_margin_utilisation:
        contracts = int(np.floor(nav * strategy_config.max_margin_utilisation / risk_per_spread))

    if contracts <= 0:
        return None

    total_credit = credit_per_spread * contracts * 100
    total_max_loss = max_loss_per_spread * contracts

    # Spot at expiry (for later P&L calc)
    spot_at_expiry = float(short_put["PriceExp"]) if "PriceExp" in short_put.index else None

    trade = SpreadTrade(
        entry_date=entry_date,
        expiry=expiry,
        short_put_strike=float(short_put["Strike"]),
        long_put_strike=float(long_put["Strike"]),
        short_put_delta=float(short_put["Delta"]),
        long_put_delta=float(long_put["Delta"]),
        short_put_mid=short_mid,
        long_put_mid=long_mid,
        entry_credit_per_spread=credit_per_spread,
        spread_width=spread_width,
        max_loss_per_spread=max_loss_per_spread,
        contracts=contracts,
        total_credit=total_credit,
        total_max_loss=total_max_loss,
        entry_spot=entry_spot,
        entry_vix=entry_vix,
        dte=dte,
        size_scalar=size_scalar,
        spot_at_expiry=spot_at_expiry,
    )

    # Optional call overlay
    if call_overlay:
        calls = chain[chain["CallPut"] == "C"].copy()
        short_call = select_strike_by_delta(calls, strategy_config.short_call_delta, "C")
        if short_call is not None:
            call_mid = float(short_call["MidPrice"]) if "MidPrice" in short_call.index else (
                (float(short_call["BestBid"]) + float(short_call["BestOffer"])) / 2
            )
            call_half_spread = (float(short_call["BestOffer"]) - float(short_call["BestBid"])) / 2
            call_sell_price = call_mid - execution_config.spread_fraction * call_half_spread
            trade.short_call_strike = float(short_call["Strike"])
            trade.short_call_delta = float(short_call["Delta"])
            trade.short_call_mid = call_mid
            trade.call_credit_per_spread = call_sell_price

    return trade
